package com.makemytrip.makemytrip.services;

import com.makemytrip.makemytrip.models.Flight;
import com.makemytrip.makemytrip.models.PriceFreeze;
import com.makemytrip.makemytrip.models.PriceSnapshot;
import com.makemytrip.makemytrip.models.Users;
import com.makemytrip.makemytrip.repositories.FlightRepository;
import com.makemytrip.makemytrip.repositories.PriceFreezeRepository;
import com.makemytrip.makemytrip.repositories.PriceSnapshotRepository;
import com.makemytrip.makemytrip.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class PricingEngine {

    @Autowired private FlightRepository flightRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private PriceSnapshotRepository snapshotRepository;
    @Autowired private PriceFreezeRepository freezeRepository;

    private static final double MIN_BOOKING_PRICE = 2000.0;

    // ── Tier resolution ─────────────────────────────────────

    public String getUserTier(String userId) {
        if (userId == null) return "BASIC";
        Users user = userRepository.findById(userId).orElse(null);
        if (user == null) return "BASIC";

        long qualifyingBookings = user.getBookings().stream()
            .filter(b -> b.getTotalPrice() >= MIN_BOOKING_PRICE)
            .count();

        if (qualifyingBookings >= 15) return "PLATINUM";
        if (qualifyingBookings >= 7)  return "GOLD";
        if (qualifyingBookings >= 3)  return "SILVER";
        return "BASIC";
    }

    public double getTierDiscount(String tier) {
        return switch (tier) {
            case "SILVER"   -> 0.05;
            case "GOLD"     -> 0.12;
            case "PLATINUM" -> 0.20;
            default         -> 0.0;
        };
    }

    // ── Demand multiplier ────────────────────────────────────

    public double getDemandMultiplier(Flight flight) {
        int total = flight.getAvailableSeats() + countBookedSeats(flight.getId());
        if (total == 0) return 1.5;
        double remaining = (double) flight.getAvailableSeats() / total;

        if (remaining > 0.70) return 1.0;
        if (remaining > 0.40) return 1.15;
        if (remaining > 0.20) return 1.30;
        return 1.50;
    }

    private int countBookedSeats(String flightId) {
        return userRepository.findAll().stream()
            .flatMap(u -> u.getBookings().stream())
            .filter(b -> flightId.equals(b.getBookingId()) && "Flight".equals(b.getType()))
            .mapToInt(Users.Booking::getQuantity)
            .sum();
    }

    // ── Effective price ──────────────────────────────────────

    public Map<String, Object> getEffectivePrice(String flightId, String userId) {
        Flight flight = flightRepository.findById(flightId)
            .orElseThrow(() -> new RuntimeException("Flight not found"));

        double multiplier = getDemandMultiplier(flight);
        double dynamicPrice = Math.round(flight.getPrice() * multiplier);

        String tier = getUserTier(userId);
        double discount = getTierDiscount(tier);
        double finalPrice = Math.round(dynamicPrice * (1 - discount));

        // Check active freeze
        boolean hasFrozen = false;
        double frozenPrice = 0;
        if (userId != null) {
            Optional<PriceFreeze> freeze = freezeRepository
                .findByUserIdAndFlightIdAndUsedFalse(userId, flightId);
            if (freeze.isPresent()) {
                LocalDateTime expiry = LocalDateTime.parse(freeze.get().getExpiresAt());
                if (expiry.isAfter(LocalDateTime.now())) {
                    hasFrozen = true;
                    frozenPrice = freeze.get().getFrozenPrice();
                    finalPrice = frozenPrice; // honour freeze
                }
            }
        }

        String multiplierReason = multiplier == 1.0 ? "Standard demand"
            : multiplier <= 1.15 ? "Moderate demand"
            : multiplier <= 1.30 ? "High demand"
            : "Very high demand — few seats left";

        Map<String, Object> result = new HashMap<>();
        result.put("flightId", flightId);
        result.put("basePrice", flight.getPrice());
        result.put("multiplier", multiplier);
        result.put("multiplierReason", multiplierReason);
        result.put("dynamicPrice", dynamicPrice);
        result.put("userTier", tier);
        result.put("tierDiscount", (int)(discount * 100) + "%");
        result.put("finalPrice", finalPrice);
        result.put("hasFrozen", hasFrozen);
        result.put("frozenPrice", frozenPrice);
        return result;
    }

    // ── Price freeze ─────────────────────────────────────────

    public PriceFreeze freezePrice(String userId, String flightId) {
        String tier = getUserTier(userId);
        int freezeMinutes = "PLATINUM".equals(tier) ? 120 : 30;

        Map<String, Object> pricing = getEffectivePrice(flightId, userId);
        double priceToFreeze = (double) pricing.get("finalPrice");

        PriceFreeze freeze = new PriceFreeze();
        freeze.setUserId(userId);
        freeze.setFlightId(flightId);
        freeze.setFrozenPrice(priceToFreeze);
        freeze.setCreatedAt(LocalDateTime.now().toString());
        freeze.setExpiresAt(LocalDateTime.now().plusMinutes(freezeMinutes).toString());
        return freezeRepository.save(freeze);
    }

    // ── Price history snapshots (hourly) ─────────────────────

    @Scheduled(fixedRate = 3600000) // every hour
    public void logPriceSnapshots() {
        List<Flight> flights = flightRepository.findAll();
        for (Flight flight : flights) {
            if (flight.isTemplate()) continue;
            double multiplier = getDemandMultiplier(flight);
            double effective = Math.round(flight.getPrice() * multiplier);

            PriceSnapshot snap = new PriceSnapshot();
            snap.setFlightId(flight.getId());
            snap.setBasePrice(flight.getPrice());
            snap.setEffectivePrice(effective);
            snap.setMultiplier(multiplier);
            snap.setReason(multiplier == 1.0 ? "Standard" : multiplier <= 1.15
                ? "Moderate demand" : multiplier <= 1.30 ? "High demand" : "Very high demand");
            snap.setTimestamp(LocalDateTime.now().toString());
            snapshotRepository.save(snap);
        }
    }

    public List<PriceSnapshot> getPriceHistory(String flightId) {
        return snapshotRepository.findByFlightIdOrderByTimestampAsc(flightId);
    }

    public List<PriceFreeze> getUserFreezes(String userId) {
        return freezeRepository.findByUserId(userId);
    }
}
