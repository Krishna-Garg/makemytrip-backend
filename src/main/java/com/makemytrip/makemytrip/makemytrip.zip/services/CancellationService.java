package com.makemytrip.makemytrip.services;

import com.makemytrip.makemytrip.models.Users.Booking;
import com.makemytrip.makemytrip.models.Users;
import com.makemytrip.makemytrip.models.Flight;

import com.makemytrip.makemytrip.repositories.FlightRepository;
import com.makemytrip.makemytrip.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.time.LocalDateTime;

@Service
public class CancellationService {
    @Autowired
    private RefundPolicyService refundPolicyService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private FlightRepository flightRepository;

    public Booking cancelBooking(String userId, String bookingId, String reason) {
        Users user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found!"));
        Booking booking = findActiveBooking(user, bookingId);
        if(!"Flight".equals(booking.getType())) {
            throw new RuntimeException("Cancellation currently only available for flights!");
        }

        LocalDateTime departureTime = parseDepartureTime(booking);

        RefundPolicyService.RefundResult refund = refundPolicyService.calculateRefund(booking.getTotalPrice(), departureTime, LocalDateTime.now());

        applyCancellation(booking, reason, refund);
        releaseSeat(booking);

        userRepository.save(user);
        return booking;
    }

    public List<Map<String, Object>> getAllCancelledBookings() {
        List<Users> allUsers = userRepository.findAll();
        List<Map<String, Object>> result = new ArrayList<>();

        for (Users user: allUsers) {
            for (Booking booking: user.getBookings()) {
                if ("CANCELLED".equals(booking.getBookingStatus())) {
                    Map<String, Object> entry = new java.util.HashMap<>();
                    entry.put("userId", user.getId());
                    entry.put("userEmail", user.getEmail());
                    entry.put("userName", user.getFirstName() + " " + user.getLastName());
                    entry.put("booking", booking);
                    result.add(entry);
                }
            }
        }
        return result;
    }

    public List<Booking> getBookingsForUser(String userId) {
        Users user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found!"));
        return user.getBookings();
    }

    public Booking updateRefundStatus(String userId, String bookingId, String newStatus) {
        Users user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found!"));
        Booking booking = user.getBookings().stream()
                .filter(b -> b.getBookingId().equals(bookingId) && "CANCELLED".equals(b.getBookingStatus()))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Cancelled booking not found!"));
        booking.setRefundStatus(newStatus);
        if("COMPLETED".equals(newStatus)) {
            booking.setRefundCompletedAt(LocalDateTime.now().toString());
        }

        userRepository.save(user);
        return booking;
    }

    private Booking findActiveBooking(Users user, String bookingId) {
        return user.getBookings().stream()
                .filter(b -> b.getBookingId().equals(bookingId) && "CONFIRMED".equals(b.getBookingStatus()))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Active booking not found"));
    }

    private LocalDateTime parseDepartureTime(Booking booking) {
        try {
            return LocalDateTime.parse(booking.getDepartureTime());
        } catch (Exception e) {
            throw new RuntimeException("Could not parse flight departure time for refund calculation");
        }
    }

    private void applyCancellation(Booking booking, String reason, RefundPolicyService.RefundResult refund) {
        booking.setBookingStatus("CANCELLED");
        booking.setCancellationReason(reason);
        booking.setCancelledAt(LocalDateTime.now().toString());
        booking.setRefundAmount(refund.refundAmount);
        booking.setRefundStatus(refund.refundPercentage > 0 ? "PENDING" : "REJECTED");
        booking.setRefundRequestedAt(LocalDateTime.now().toString());
        booking.setRefundEta(refund.estimatedEta);
    }

    private void releaseSeat(Booking booking) {
        flightRepository.findById(booking.getBookingId()).ifPresent(flight -> {
            flight.setAvailableSeats(flight.getAvailableSeats() + booking.getQuantity());
            flightRepository.save(flight);
        });
    }
}
